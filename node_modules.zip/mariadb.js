const express = require('express')

const mariadb = require('mariadb');

const pug = require('pug');



const pool = mariadb.createPool({
    host: 'localhost',
    port: 13064,
    user:'master',
    password: 'password',
    database: 'schule'
});

async function newQuery( query ){
    let conn;
    var result = '';
    try {
        conn = await pool.getConnection();
        result = await conn.query(query);
    } catch (err) {
        throw err;
    } finally {
        if (conn) conn.release();
    }
    return result;
};



const app = express()
const port = 4000;

app.use(express.static(__dirname + '/static'));

app.get('/tables', async (req, res) => {
    var result = await newQuery('show tables');
    res.send((pug.renderFile('pugs/template.pug', {
        result: result
    })));
});

app.get('/lehrernachfach', async (req, res) => {
    var result = await newQuery('show tables');
    res.send((pug.renderFile('pugs/template.pug', {
        result: (pug.renderFile('pugs/lehrernachfach.pug', {
            result: result ,
        }))
    })));
});



app.get('/teacherquery', async (req, res) => {
//"select * from lehrkraft where kernfach = 'Bio' or nebenfach='Bio'"
    var query = "select * from lehrkraft where kernfach = "+"'"+req.query.sqlquery+"'"+" or nebenfach="+"'"+req.query.sqlquery+"'";
    console.log("teacher query")
    console.log(req.query.sqlquery)
    console.log(query)
    var result = await newQuery(query);
    res.send((pug.renderFile('pugs/template.pug', {
        result: (pug.renderFile('pugs/lehrernachfach.pug', {
            result: result,
        }))
    })))
});

app.get('/bookquery', async (req, res) => {
//SELECT Name,Vornamen,Titel FROM buch join schüler WHERE Titel = "Home Alone 2: Lost in New York" AND AusgeliehenSchülerID = SchülerID
    var query = "SELECT Name,Vornamen,Titel FROM buch join schüler WHERE Titel LIKE '%"+req.query.sqlquery+"%' AND AusgeliehenSchülerID = SchülerID"
    console.log("teacher query")
    console.log(req.query.sqlquery)
    console.log(query)
    var result = await newQuery(query);
    res.send((pug.renderFile('pugs/template.pug', {
        result: (pug.renderFile('pugs/buchnachtitel.pug', {
            result: result,
        }))
    })))
});

app.get('/', async (req, res) => {

    res.send((pug.renderFile('pugs/template.pug', {
        name: 'Timothy'
    })));
});

app.listen(port, () => console.log(`Server running on ${port}`));

